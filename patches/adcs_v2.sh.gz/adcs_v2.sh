#!/bin/sh

(
cat /data/adcs_v2.0 /data/adcs_v2.1 /data/adcs_v2.2 /data/adcs_v2.3 /data/adcs_v2.4 > /data/adcs_v2.gz
rm -f /data/adcs_v2
gzip -d /data/adcs_v2.gz
chmod a+rx /data/adcs_v2
md5sum /data/adcs_v2

cat /data/adcs-util_v2.0 /data/adcs-util_v2.1 /data/adcs-util_v2.2 /data/adcs-util_v2.3 /data/adcs-util_v2.4 /data/adcs-util_v2.5  /data/adcs-util_v2.6 > /data/adcs-util_v2.gz
rm -f /data/adcs-util_v2
gzip -d /data/adcs-util_v2.gz
chmod a+rx /data/adcs-util_v2
md5sum /data/adcs-util_v2

mount
mount -oremount,rw /usr/local
mount

cp /usr/local/etc/dl_config/adcs.cfg /usr/local/etc/adcs1.cfg
cd /usr/local/etc/dl_config
patch adcs.cfg <<EOF
--- old.cfg	2019-02-13 17:35:39.228813049 -0800
+++ new.cfg	2019-02-13 17:37:58.550167097 -0800
@@ -97,4 +97,109 @@
       GROUPS=adcs
    </SENSOR>
 
+   <SENSOR>
+      NAME=adcs
+      SENSOR_KEY=nz_mag_x
+      LOCATION=adcs
+      GROUPS=adcs
+   </SENSOR>
+
+   <SENSOR>
+      NAME=adcs
+      SENSOR_KEY=nz_mag_y
+      LOCATION=adcs
+      GROUPS=adcs
+   </SENSOR>
+
+   <SENSOR>
+      NAME=adcs
+      SENSOR_KEY=nz_mag_z
+      LOCATION=adcs
+      GROUPS=adcs
+   </SENSOR>
+
+   <SENSOR>
+      NAME=adcs
+      SENSOR_KEY=ny_mag_x
+      LOCATION=adcs
+      GROUPS=adcs
+   </SENSOR>
+
+   <SENSOR>
+      NAME=adcs
+      SENSOR_KEY=ny_mag_y
+      LOCATION=adcs
+      GROUPS=adcs
+   </SENSOR>
+
+   <SENSOR>
+      NAME=adcs
+      SENSOR_KEY=ny_mag_z
+      LOCATION=adcs
+      GROUPS=adcs
+   </SENSOR>
+
+   <SENSOR>
+      NAME=adcs
+      SENSOR_KEY=py_mag_x
+      LOCATION=adcs
+      GROUPS=adcs
+   </SENSOR>
+
+   <SENSOR>
+      NAME=adcs
+      SENSOR_KEY=py_mag_y
+      LOCATION=adcs
+      GROUPS=adcs
+   </SENSOR>
+
+   <SENSOR>
+      NAME=adcs
+      SENSOR_KEY=py_mag_z
+      LOCATION=adcs
+      GROUPS=adcs
+   </SENSOR>
+
+   <SENSOR>
+      NAME=adcs
+      SENSOR_KEY=px_mag_x
+      LOCATION=adcs
+      GROUPS=adcs
+   </SENSOR>
+
+   <SENSOR>
+      NAME=adcs
+      SENSOR_KEY=px_mag_y
+      LOCATION=adcs
+      GROUPS=adcs
+   </SENSOR>
+
+   <SENSOR>
+      NAME=adcs
+      SENSOR_KEY=px_mag_z
+      LOCATION=adcs
+      GROUPS=adcs
+   </SENSOR>
+
+   <SENSOR>
+      NAME=adcs
+      SENSOR_KEY=nx_mag_x
+      LOCATION=adcs
+      GROUPS=adcs
+   </SENSOR>
+
+   <SENSOR>
+      NAME=adcs
+      SENSOR_KEY=nx_mag_y
+      LOCATION=adcs
+      GROUPS=adcs
+   </SENSOR>
+
+   <SENSOR>
+      NAME=adcs
+      SENSOR_KEY=nx_mag_z
+      LOCATION=adcs
+      GROUPS=adcs
+   </SENSOR>
+
 </SUBPROCESS>
EOF

cd /data
echo /usr/local/etc/dl_config/adcs.cfg
md5sum /usr/local/etc/dl_config/adcs.cfg
cp -f /data/adcs_v2 /usr/local/bin
chmod a+rx /usr/local/bin/adcs_v2
cp -f /data/adcs-util_v2 /usr/local/bin
chmod a+rx /usr/local/bin/adcs-util_v2

mount -oremount,ro /usr/local
mount
ls -l /usr/local/etc

cat > /data/patch.sh <<EOF
#!/bin/sh
if [ -x /usr/local/bin/adcs_v2 ] ; then
   cp -f /usr/local/bin/adcs_v2 /usr/bin/adcs
   chmod a+rx /usr/bin/adcs
fi
if [ -x /usr/local/bin/adcs-util_v2 ] ; then
   cp -f /usr/local/bin/adcs-util_v2 /usr/bin/adcs-util
   chmod a+rx /usr/bin/adcs-util
   ln -s /usr/bin/adcs-util /usr/bin/adcs-get-cs
   ln -s /usr/bin/adcs-util /usr/bin/adcs-set-cs
   ln -s /usr/bin/adcs-util /usr/bin/adcs-read-dump
fi
EOF
chmod a+rx /data/patch.sh
echo /data/patch.sh
md5sum /data/patch.sh

ls -l /data
) > /data/adcs_v2.txt 2>&1
gzip /data/adcs_v2.txt
dlq-add -g 4 -p 64 /data/adcs_v2.txt.gz
